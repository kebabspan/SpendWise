# SpendWise integrated project

Ez a csomag két részt tartalmaz:

- `backend/` – a feltöltött NestJS backend változatlanul
- `frontend/` – új, Next.js alapú frontend a template kinézetével, de a saját backend végpontjaihoz kötve

## Fontos változások

A template-ből ki lettek hagyva azok a részek, amelyek itt nem kellenek:

- Supabase auth / adatkapcsolat
- belső `app/api/*` route-ok
- Resend / email template logika
- LemonSqueezy / subscription flow
- fölösleges marketing / privacy / middleware / email workspace elemek

A frontend most közvetlenül ezeket a backend végpontokat használja:

- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/user/me`
- `PATCH /api/user/update`
- `GET/POST/DELETE /api/accounts`
- `GET/POST/DELETE /api/categories`
- `GET/POST/DELETE /api/transactions`
- `GET/POST/DELETE /api/budgets`

## Indítás

### Backend

```bash
cd backend
npm install
npm run start:dev
```

### Frontend

```bash
cd frontend
cp .env.example .env.local # vagy kézzel hozd létre
npm install
npm run dev
```

`frontend/.env.local` tartalma:

```env
NEXT_PUBLIC_API_URL=http://localhost:3000/api
```

A frontend alapértelmezetten JWT tokent ment `localStorage`-ba `spendwise_token` néven.

## Megjegyzések

- A tranzakciós képernyő a backend DTO-jához van igazítva (`description`, `accountId`, `toAccountId`).
- A budget oldalon csak `EXPENSE` kategóriákból lehet választani.
- A dizájn könnyen továbbírható a saját elnevezéseitekre.
