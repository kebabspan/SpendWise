import Link from 'next/link';

export default function HomePage() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-background to-muted">
      <div className="container py-24">
        <div className="mx-auto max-w-5xl rounded-[32px] border bg-card p-10 shadow-sm">
          <div className="grid gap-10 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
            <div>
              <div className="mb-4 inline-flex rounded-full border px-3 py-1 text-xs font-medium text-muted-foreground">Expense.fyi hangulat · saját backend</div>
              <h1 className="text-5xl font-semibold tracking-tight">SpendWise frontend, összekötve a NestJS backenddel.</h1>
              <p className="mt-5 max-w-2xl text-lg text-muted-foreground">A fölösleges Supabase / Resend / belső adatbázisos részek helyett ez a verzió közvetlenül a saját API-végpontjaidat használja. A dashboard kattintható, CRUD műveletekkel.</p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link href="/signin" className="inline-flex h-11 items-center rounded-xl bg-primary px-5 text-sm font-medium text-primary-foreground">Bejelentkezés</Link>
                <Link href="/signup" className="inline-flex h-11 items-center rounded-xl border px-5 text-sm font-medium">Regisztráció</Link>
                <Link href="/dashboard" className="inline-flex h-11 items-center rounded-xl border px-5 text-sm font-medium">Dashboard megnyitása</Link>
              </div>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              {[
                ['Auth', 'JWT alapú login / register'],
                ['Accounts', 'Számlák kezelése'],
                ['Categories', 'Bevétel és kiadás kategóriák'],
                ['Transactions', 'Új tranzakciók és listázás'],
                ['Budgets', 'Havi budgetek'],
                ['Settings', 'Profil frissítés'],
              ].map(([title, desc]) => (
                <div key={title} className="rounded-2xl border bg-background p-5">
                  <div className="text-lg font-semibold">{title}</div>
                  <div className="mt-1 text-sm text-muted-foreground">{desc}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
