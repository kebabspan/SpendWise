'use client';

import { Button, Card, Input } from '@/components/ui';
import { apiFetch, setToken } from '@/lib/api';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';

export default function SignInPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const router = useRouter();

  return (
    <main className="flex min-h-screen items-center justify-center bg-muted/40 p-4">
      <Card className="w-full max-w-md p-6">
        <h1 className="text-2xl font-semibold">Bejelentkezés</h1>
        <p className="mt-1 text-sm text-muted-foreground">A backend /auth/login végpontját használja.</p>
        <div className="mt-6 space-y-3">
          <Input placeholder="E-mail" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <Input placeholder="Jelszó" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <Button className="w-full" onClick={async () => {
            try {
              const result = await apiFetch<{ access_token: string }>('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) });
              setToken(result.access_token);
              router.push('/dashboard');
            } catch (e: any) {
              setError(e.message);
            }
          }}>Belépés</Button>
          {error && <p className="text-sm text-destructive">{error}</p>}
        </div>
        <p className="mt-4 text-sm text-muted-foreground">Nincs még fiókod? <Link className="font-medium text-foreground" href="/signup">Regisztrálj</Link></p>
      </Card>
    </main>
  );
}
