'use client';

import { Button, Card, Input } from '@/components/ui';
import { apiFetch } from '@/lib/api';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';

export default function SignUpPage() {
  const [form, setForm] = useState({ name: '', email: '', password: '', currency: 'HUF' });
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const router = useRouter();

  return (
    <main className="flex min-h-screen items-center justify-center bg-muted/40 p-4">
      <Card className="w-full max-w-md p-6">
        <h1 className="text-2xl font-semibold">Regisztráció</h1>
        <p className="mt-1 text-sm text-muted-foreground">Új felhasználó a backend /auth/register végpontjára küldve.</p>
        <div className="mt-6 space-y-3">
          <Input placeholder="Név" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <Input placeholder="E-mail" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          <Input placeholder="Jelszó" type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
          <Input placeholder="Pénznem" value={form.currency} onChange={(e) => setForm({ ...form, currency: e.target.value })} />
          <Button className="w-full" onClick={async () => {
            try {
              await apiFetch('/auth/register', { method: 'POST', body: JSON.stringify(form) });
              setMessage('Sikeres regisztráció. Most be tudsz jelentkezni.');
              setTimeout(() => router.push('/signin'), 600);
            } catch (e: any) {
              setError(e.message);
            }
          }}>Fiók létrehozása</Button>
          {error && <p className="text-sm text-destructive">{error}</p>}
          {message && <p className="text-sm text-green-600">{message}</p>}
        </div>
        <p className="mt-4 text-sm text-muted-foreground">Van már fiókod? <Link className="font-medium text-foreground" href="/signin">Belépés</Link></p>
      </Card>
    </main>
  );
}
