import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateRecurringDto, UpdateRecurringDto } from './recurring.dto';

@Injectable()
export class RecurringService {
  constructor(private prisma: PrismaService) {}

  findAll(userId: string) {
    return this.prisma.recurringTransaction.findMany({
      where: { userId },
      include: { category: true, account: true },
      orderBy: { nextDate: 'asc' },
    });
  }

  create(userId: string, dto: CreateRecurringDto) {
    return this.prisma.recurringTransaction.create({
      data: {
        name: dto.name,
        amount: dto.amount,
        type: dto.type as any,
        frequency: dto.frequency as any,
        nextDate: new Date(dto.nextDate),
        categoryId: dto.categoryId,
        accountId: dto.accountId,
        userId,
      },
      include: { category: true, account: true },
    });
  }

  async update(userId: string, id: string, dto: UpdateRecurringDto) {
    const r = await this.prisma.recurringTransaction.findFirst({ where: { id, userId } });
    if (!r) throw new NotFoundException();
    return this.prisma.recurringTransaction.update({
      where: { id },
      data: {
        ...dto,
        nextDate: dto.nextDate ? new Date(dto.nextDate) : undefined,
        frequency: dto.frequency as any,
      },
      include: { category: true, account: true },
    });
  }

  async delete(userId: string, id: string) {
    const r = await this.prisma.recurringTransaction.findFirst({ where: { id, userId } });
    if (!r) throw new NotFoundException();
    return this.prisma.recurringTransaction.delete({ where: { id } });
  }
}
