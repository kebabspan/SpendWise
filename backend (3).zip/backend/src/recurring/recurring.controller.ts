import { Body, Controller, Delete, Get, Param, Patch, Post, Request } from '@nestjs/common';
import { RecurringService } from './recurring.service';
import { CreateRecurringDto, UpdateRecurringDto } from './recurring.dto';

@Controller('recurring')
export class RecurringController {
  constructor(private recurringService: RecurringService) {}
  @Get()    getAll(@Request() req) { return this.recurringService.findAll(req.user.userId); }
  @Post()   create(@Request() req, @Body() dto: CreateRecurringDto) { return this.recurringService.create(req.user.userId, dto); }
  @Patch(':id') update(@Request() req, @Param('id') id: string, @Body() dto: UpdateRecurringDto) { return this.recurringService.update(req.user.userId, id, dto); }
  @Delete(':id') delete(@Request() req, @Param('id') id: string) { return this.recurringService.delete(req.user.userId, id); }
}
