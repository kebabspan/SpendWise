import { Body, Controller, Delete, Get, Param, Patch, Post, Request } from '@nestjs/common';
import { GoalsService } from './goals.service';
import { CreateGoalDto, UpdateGoalDto, AddToGoalDto } from './goals.dto';

@Controller('goals')
export class GoalsController {
  constructor(private goalsService: GoalsService) {}
  @Get()    getAll(@Request() req) { return this.goalsService.findAll(req.user.userId); }
  @Post()   create(@Request() req, @Body() dto: CreateGoalDto) { return this.goalsService.create(req.user.userId, dto); }
  @Patch(':id') update(@Request() req, @Param('id') id: string, @Body() dto: UpdateGoalDto) { return this.goalsService.update(req.user.userId, id, dto); }
  @Post(':id/add') addAmount(@Request() req, @Param('id') id: string, @Body() dto: AddToGoalDto) { return this.goalsService.addAmount(req.user.userId, id, dto.amount); }
  @Delete(':id') delete(@Request() req, @Param('id') id: string) { return this.goalsService.delete(req.user.userId, id); }
}
