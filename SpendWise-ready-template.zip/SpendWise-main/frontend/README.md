# SpendWise frontend

## Start
```bash
npm install
npm run dev
```

## Default backend URL
```env
VITE_API_URL=http://localhost:3001/api
```

## Fast rename points
- `src/lib/site.ts`
- `src/pages/*`
- `src/components/layout/AppShell.tsx`
