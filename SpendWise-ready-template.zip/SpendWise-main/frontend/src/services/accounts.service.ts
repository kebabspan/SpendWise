import { api } from '../lib/app';
import type { Account, AccountPayload } from '../types/account';

export const accountsService = {
  async getAll() {
    const { data } = await api.get<Account[]>('/accounts');
    return data;
  },
  async create(payload: AccountPayload) {
    const { data } = await api.post<Account>('/accounts', payload);
    return data;
  },
  async update(id: string, payload: AccountPayload) {
    const { data } = await api.patch<Account>(`/accounts/${id}`, payload);
    return data;
  },
  async remove(id: string) {
    const { data } = await api.delete<Account>(`/accounts/${id}`);
    return data;
  },
};
