import { api } from '../lib/app';
import type { Category, CategoryPayload } from '../types/category';

export const categoriesService = {
  async getAll() {
    const { data } = await api.get<Category[]>('/categories');
    return data;
  },
  async create(payload: CategoryPayload) {
    const { data } = await api.post<Category>('/categories', payload);
    return data;
  },
  async update(id: string, payload: Partial<CategoryPayload>) {
    const { data } = await api.patch<Category>(`/categories/${id}`, payload);
    return data;
  },
  async remove(id: string) {
    const { data } = await api.delete<Category>(`/categories/${id}`);
    return data;
  },
};
