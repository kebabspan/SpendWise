import { api } from '../lib/app';
import type { Budget, BudgetPayload } from '../types/budget';

export const budgetsService = {
  async getAll() {
    const { data } = await api.get<Budget[]>('/budgets');
    return data;
  },
  async create(payload: BudgetPayload) {
    const { data } = await api.post<Budget>('/budgets', payload);
    return data;
  },
  async remove(id: string) {
    const { data } = await api.delete<Budget>(`/budgets/${id}`);
    return data;
  },
};
