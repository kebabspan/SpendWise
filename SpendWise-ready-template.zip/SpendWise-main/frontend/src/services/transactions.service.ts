import { api } from '../lib/app';
import type { Transaction, TransactionPayload } from '../types/transaction';

export const transactionsService = {
  async getAll() {
    const { data } = await api.get<Transaction[]>('/transactions');
    return data;
  },
  async create(payload: TransactionPayload) {
    const { data } = await api.post<Transaction>('/transactions', payload);
    return data;
  },
  async remove(id: string) {
    const { data } = await api.delete<Transaction>(`/transactions/${id}`);
    return data;
  },
};
