import { api } from '../lib/app';
import type { AuthResponse, LoginPayload, RegisterPayload } from '../types/auth';

export const authService = {
  async login(payload: LoginPayload) {
    const { data } = await api.post<AuthResponse>('/auth/login', payload);
    return data;
  },
  async register(payload: RegisterPayload) {
    const { data } = await api.post('/auth/register', payload);
    return data;
  },
};
