import { api } from '../lib/app';
import type { UpdateUserPayload, UserProfile } from '../types/user';

export const userService = {
  async getMe() {
    const { data } = await api.get<UserProfile>('/user/me');
    return data;
  },
  async update(payload: UpdateUserPayload) {
    const { data } = await api.patch<UserProfile>('/user/update', payload);
    return data;
  },
};
