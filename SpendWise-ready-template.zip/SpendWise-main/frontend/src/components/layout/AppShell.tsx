import logo from '../../assets/logo.svg';
import {
  AppBar,
  Avatar,
  Box,
  Chip,
  Divider,
  Drawer,
  IconButton,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Stack,
  Toolbar,
  Tooltip,
  Typography,
  useMediaQuery,
} from '@mui/material';
import DashboardRoundedIcon from '@mui/icons-material/DashboardRounded';
import WalletRoundedIcon from '@mui/icons-material/WalletRounded';
import CategoryRoundedIcon from '@mui/icons-material/CategoryRounded';
import SavingsRoundedIcon from '@mui/icons-material/SavingsRounded';
import ReceiptLongRoundedIcon from '@mui/icons-material/ReceiptLongRounded';
import PersonRoundedIcon from '@mui/icons-material/PersonRounded';
import LoginRoundedIcon from '@mui/icons-material/LoginRounded';
import AppRegistrationRoundedIcon from '@mui/icons-material/AppRegistrationRounded';
import LogoutRoundedIcon from '@mui/icons-material/LogoutRounded';
import MenuRoundedIcon from '@mui/icons-material/MenuRounded';
import { alpha, useTheme } from '@mui/material/styles';
import { useMemo, useState, type ReactNode } from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { siteConfig } from '../../lib/site';

const drawerWidth = 280;

interface NavItem {
  label: string;
  icon: ReactNode;
  path: string;
}

function BrandBlock() {
  return (
    <Stack direction="row" spacing={1.5} alignItems="center">
      <Box
        component="img"
        src={logo}
        alt={siteConfig.appName}
        sx={{ width: 38, height: 38, borderRadius: 2 }}
      />
      <Box>
        <Typography fontWeight={800}>{siteConfig.appName}</Typography>
        <Typography variant="caption" color="text.secondary">
          {siteConfig.tagline}
        </Typography>
      </Box>
    </Stack>
  );
}

export default function AppShell() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const theme = useTheme();
  const isDesktop = useMediaQuery(theme.breakpoints.up('lg'));
  const [mobileOpen, setMobileOpen] = useState(false);
  const { isAuthenticated, isDemoMode, logout, user } = useAuth();

  const navItems = useMemo<NavItem[]>(
    () => [
      { label: 'Dashboard', icon: <DashboardRoundedIcon />, path: '/' },
      { label: 'Accounts', icon: <WalletRoundedIcon />, path: '/accounts' },
      { label: 'Categories', icon: <CategoryRoundedIcon />, path: '/categories' },
      { label: 'Budgets', icon: <SavingsRoundedIcon />, path: '/budgets' },
      { label: 'Transactions', icon: <ReceiptLongRoundedIcon />, path: '/transactions' },
      { label: 'Profile', icon: <PersonRoundedIcon />, path: '/profile' },
    ],
    [],
  );

  const authItems = isAuthenticated
    ? [{ label: 'Log out', icon: <LogoutRoundedIcon />, onClick: logout }]
    : [
        { label: 'Login', icon: <LoginRoundedIcon />, onClick: () => navigate('/login') },
        { label: 'Register', icon: <AppRegistrationRoundedIcon />, onClick: () => navigate('/register') },
      ];

  const drawerContent = (
    <Stack sx={{ height: '100%' }}>
      <Box sx={{ px: 3, py: 2.5 }}>
        <BrandBlock />
      </Box>
      <Divider />
      <Box sx={{ px: 2, py: 2 }}>
        <List sx={{ display: 'grid', gap: 0.5 }}>
          {navItems.map((item) => {
            const selected = pathname === item.path;
            return (
              <ListItemButton
                key={item.path}
                component={NavLink}
                to={item.path}
                selected={selected}
                onClick={() => setMobileOpen(false)}
                sx={{ borderRadius: 3, py: 1.2 }}
              >
                <ListItemIcon sx={{ minWidth: 40 }}>{item.icon}</ListItemIcon>
                <ListItemText primary={item.label} />
              </ListItemButton>
            );
          })}
        </List>
      </Box>
      <Box sx={{ mt: 'auto', p: 2 }}>
        <Stack spacing={1.5}>
          <Box
            sx={{
              p: 2,
              borderRadius: 4,
              background: alpha(theme.palette.primary.main, 0.08),
            }}
          >
            <Stack direction="row" justifyContent="space-between" alignItems="center" mb={1}>
              <Typography fontWeight={700}>Workspace</Typography>
              <Chip
                size="small"
                color={isDemoMode ? 'warning' : 'success'}
                label={isDemoMode ? 'Demo' : 'Live'}
              />
            </Stack>
            <Typography variant="body2" color="text.secondary">
              {isDemoMode
                ? 'Preview mode with sample data.'
                : 'Connected to the SpendWise backend.'}
            </Typography>
          </Box>

          <List sx={{ display: 'grid', gap: 0.5 }}>
            {authItems.map((item) => (
              <ListItemButton key={item.label} onClick={item.onClick} sx={{ borderRadius: 3 }}>
                <ListItemIcon sx={{ minWidth: 40 }}>{item.icon}</ListItemIcon>
                <ListItemText primary={item.label} />
              </ListItemButton>
            ))}
          </List>
        </Stack>
      </Box>
    </Stack>
  );

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: '#f5f7fb' }}>
      <AppBar
        position="fixed"
        color="inherit"
        elevation={0}
        sx={{
          width: { lg: `calc(100% - ${drawerWidth}px)` },
          ml: { lg: `${drawerWidth}px` },
          backdropFilter: 'blur(12px)',
          bgcolor: alpha(theme.palette.background.paper, 0.82),
          borderBottom: `1px solid ${theme.palette.divider}`,
        }}
      >
        <Toolbar sx={{ justifyContent: 'space-between' }}>
          <Stack direction="row" alignItems="center" spacing={1.5}>
            {!isDesktop ? (
              <IconButton onClick={() => setMobileOpen(true)}>
                <MenuRoundedIcon />
              </IconButton>
            ) : null}
            <Box>
              <Typography fontWeight={800}>Frontend template ready</Typography>
              <Typography variant="body2" color="text.secondary">
                Rename texts in <strong>src/lib/site.ts</strong> and route pages.
              </Typography>
            </Box>
          </Stack>

          <Stack direction="row" alignItems="center" spacing={1.5}>
            <Tooltip title={user?.email || 'Guest mode'}>
              <Avatar sx={{ bgcolor: 'primary.main' }}>{(user?.name || 'G').charAt(0)}</Avatar>
            </Tooltip>
          </Stack>
        </Toolbar>
      </AppBar>

      <Box component="nav" sx={{ width: { lg: drawerWidth }, flexShrink: { lg: 0 } }}>
        <Drawer
          variant={isDesktop ? 'permanent' : 'temporary'}
          open={isDesktop ? true : mobileOpen}
          onClose={() => setMobileOpen(false)}
          ModalProps={{ keepMounted: true }}
          sx={{
            '& .MuiDrawer-paper': {
              width: drawerWidth,
              borderRight: `1px solid ${theme.palette.divider}`,
            },
          }}
        >
          {drawerContent}
        </Drawer>
      </Box>

      <Box component="main" sx={{ flexGrow: 1, p: { xs: 2, md: 3 }, mt: 10 }}>
        <Outlet />
      </Box>
    </Box>
  );
}
