import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  MenuItem,
  Stack,
  TextField,
} from '@mui/material';
import { useEffect, useMemo, useState } from 'react';
import type { Account } from '../../types/account';
import type { Category } from '../../types/category';
import type { TransactionType } from '../../types/transaction';

interface TransactionDialogProps {
  open: boolean;
  accounts: Account[];
  categories: Category[];
  onClose: () => void;
  onSubmit: (payload: {
    amount: number;
    description?: string;
    place?: string;
    date?: string;
    type: TransactionType;
    categoryId?: string;
    accountId: string;
    toAccountId?: string;
  }) => Promise<void>;
}

export default function TransactionDialog({
  open,
  accounts,
  categories,
  onClose,
  onSubmit,
}: TransactionDialogProps) {
  const [form, setForm] = useState({
    amount: 0,
    description: '',
    place: '',
    date: new Date().toISOString().slice(0, 10),
    type: 'EXPENSE' as TransactionType,
    categoryId: '',
    accountId: '',
    toAccountId: '',
  });

  const filteredCategories = useMemo(() => {
    if (form.type === 'TRANSFER') return [];
    return categories.filter((category) => category.type === form.type);
  }, [categories, form.type]);

  useEffect(() => {
    if (open) {
      setForm({
        amount: 0,
        description: '',
        place: '',
        date: new Date().toISOString().slice(0, 10),
        type: 'EXPENSE',
        categoryId: categories.find((category) => category.type === 'EXPENSE')?.id || '',
        accountId: accounts[0]?.id || '',
        toAccountId: accounts[1]?.id || '',
      });
    }
  }, [accounts, categories, open]);

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="sm">
      <DialogTitle>Create transaction</DialogTitle>
      <DialogContent>
        <Stack spacing={2} mt={1}>
          <TextField
            label="Amount"
            type="number"
            value={form.amount}
            onChange={(event) => setForm((prev) => ({ ...prev, amount: Number(event.target.value) }))}
            fullWidth
          />
          <TextField
            select
            label="Type"
            value={form.type}
            onChange={(event) =>
              setForm((prev) => ({
                ...prev,
                type: event.target.value as TransactionType,
                categoryId:
                  event.target.value === 'TRANSFER'
                    ? ''
                    : categories.find((category) => category.type === event.target.value)?.id || '',
              }))
            }
            fullWidth
          >
            <MenuItem value="EXPENSE">Expense</MenuItem>
            <MenuItem value="INCOME">Income</MenuItem>
            <MenuItem value="TRANSFER">Transfer</MenuItem>
          </TextField>
          <TextField
            label="Description"
            value={form.description}
            onChange={(event) => setForm((prev) => ({ ...prev, description: event.target.value }))}
            fullWidth
          />
          <TextField
            label="Place"
            value={form.place}
            onChange={(event) => setForm((prev) => ({ ...prev, place: event.target.value }))}
            fullWidth
          />
          <TextField
            label="Date"
            type="date"
            value={form.date}
            onChange={(event) => setForm((prev) => ({ ...prev, date: event.target.value }))}
            fullWidth
            InputLabelProps={{ shrink: true }}
          />
          <TextField
            select
            label={form.type === 'TRANSFER' ? 'From account' : 'Account'}
            value={form.accountId}
            onChange={(event) => setForm((prev) => ({ ...prev, accountId: event.target.value }))}
            fullWidth
          >
            {accounts.map((account) => (
              <MenuItem value={account.id} key={account.id}>
                {account.name}
              </MenuItem>
            ))}
          </TextField>
          {form.type === 'TRANSFER' ? (
            <TextField
              select
              label="To account"
              value={form.toAccountId}
              onChange={(event) => setForm((prev) => ({ ...prev, toAccountId: event.target.value }))}
              fullWidth
            >
              {accounts.map((account) => (
                <MenuItem value={account.id} key={account.id}>
                  {account.name}
                </MenuItem>
              ))}
            </TextField>
          ) : (
            <TextField
              select
              label="Category"
              value={form.categoryId}
              onChange={(event) => setForm((prev) => ({ ...prev, categoryId: event.target.value }))}
              fullWidth
            >
              {filteredCategories.map((category) => (
                <MenuItem value={category.id} key={category.id}>
                  {category.name}
                </MenuItem>
              ))}
            </TextField>
          )}
        </Stack>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={() => void onSubmit(form)}>
          Save
        </Button>
      </DialogActions>
    </Dialog>
  );
}
