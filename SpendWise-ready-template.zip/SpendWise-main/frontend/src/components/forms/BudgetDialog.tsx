import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  MenuItem,
  Stack,
  TextField,
} from '@mui/material';
import { useEffect, useState } from 'react';
import type { Category } from '../../types/category';

interface BudgetDialogProps {
  open: boolean;
  categories: Category[];
  onClose: () => void;
  onSubmit: (payload: {
    limitAmount: number;
    month: number;
    year: number;
    categoryId: string;
  }) => Promise<void>;
}

export default function BudgetDialog({ open, categories, onClose, onSubmit }: BudgetDialogProps) {
  const [form, setForm] = useState({
    limitAmount: 50000,
    month: new Date().getMonth() + 1,
    year: new Date().getFullYear(),
    categoryId: '',
  });

  useEffect(() => {
    if (open) {
      setForm((prev) => ({
        ...prev,
        categoryId: categories.find((category) => category.type === 'EXPENSE')?.id || '',
      }));
    }
  }, [categories, open]);

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="sm">
      <DialogTitle>Create budget</DialogTitle>
      <DialogContent>
        <Stack spacing={2} mt={1}>
          <TextField
            label="Limit amount"
            type="number"
            value={form.limitAmount}
            onChange={(event) =>
              setForm((prev) => ({ ...prev, limitAmount: Number(event.target.value) }))
            }
            fullWidth
          />
          <TextField
            label="Month"
            type="number"
            value={form.month}
            onChange={(event) => setForm((prev) => ({ ...prev, month: Number(event.target.value) }))}
            fullWidth
          />
          <TextField
            label="Year"
            type="number"
            value={form.year}
            onChange={(event) => setForm((prev) => ({ ...prev, year: Number(event.target.value) }))}
            fullWidth
          />
          <TextField
            select
            label="Expense category"
            value={form.categoryId}
            onChange={(event) => setForm((prev) => ({ ...prev, categoryId: event.target.value }))}
            fullWidth
          >
            {categories
              .filter((category) => category.type === 'EXPENSE')
              .map((category) => (
                <MenuItem value={category.id} key={category.id}>
                  {category.name}
                </MenuItem>
              ))}
          </TextField>
        </Stack>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={() => void onSubmit(form)}>
          Save
        </Button>
      </DialogActions>
    </Dialog>
  );
}
