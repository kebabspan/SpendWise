import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Stack,
  TextField,
} from '@mui/material';
import { useEffect, useState } from 'react';
import type { Account } from '../../types/account';

interface AccountDialogProps {
  open: boolean;
  initialValue?: Account | null;
  onClose: () => void;
  onSubmit: (payload: { name: string; balance: number; color?: string; icon?: string }) => Promise<void>;
}

const blankState = {
  name: '',
  balance: 0,
  color: '#1976d2',
  icon: 'account_balance',
};

export default function AccountDialog({ open, initialValue, onClose, onSubmit }: AccountDialogProps) {
  const [form, setForm] = useState(blankState);

  useEffect(() => {
    if (initialValue) {
      setForm({
        name: initialValue.name,
        balance: Number(initialValue.balance),
        color: initialValue.color || '#1976d2',
        icon: initialValue.icon || 'account_balance',
      });
    } else {
      setForm(blankState);
    }
  }, [initialValue, open]);

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="sm">
      <DialogTitle>{initialValue ? 'Edit account' : 'Create account'}</DialogTitle>
      <DialogContent>
        <Stack spacing={2} mt={1}>
          <TextField
            label="Account name"
            value={form.name}
            onChange={(event) => setForm((prev) => ({ ...prev, name: event.target.value }))}
            fullWidth
          />
          <TextField
            label="Balance"
            type="number"
            value={form.balance}
            onChange={(event) =>
              setForm((prev) => ({ ...prev, balance: Number(event.target.value) }))
            }
            fullWidth
          />
          <TextField
            label="Color"
            value={form.color}
            onChange={(event) => setForm((prev) => ({ ...prev, color: event.target.value }))}
            fullWidth
          />
          <TextField
            label="Icon"
            value={form.icon}
            onChange={(event) => setForm((prev) => ({ ...prev, icon: event.target.value }))}
            fullWidth
          />
        </Stack>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={() => void onSubmit(form)}>
          Save
        </Button>
      </DialogActions>
    </Dialog>
  );
}
