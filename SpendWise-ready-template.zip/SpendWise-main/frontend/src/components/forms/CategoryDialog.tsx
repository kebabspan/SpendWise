import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  MenuItem,
  Stack,
  TextField,
} from '@mui/material';
import { useEffect, useState } from 'react';
import type { Category, CategoryType } from '../../types/category';

interface CategoryDialogProps {
  open: boolean;
  initialValue?: Category | null;
  onClose: () => void;
  onSubmit: (payload: {
    name: string;
    type: CategoryType;
    color?: string;
    icon?: string;
  }) => Promise<void>;
}

const blankState = {
  name: '',
  type: 'EXPENSE' as CategoryType,
  color: '#ef5350',
  icon: 'category',
};

export default function CategoryDialog({ open, initialValue, onClose, onSubmit }: CategoryDialogProps) {
  const [form, setForm] = useState(blankState);

  useEffect(() => {
    if (initialValue) {
      setForm({
        name: initialValue.name,
        type: initialValue.type,
        color: initialValue.color || '#ef5350',
        icon: initialValue.icon || 'category',
      });
    } else {
      setForm(blankState);
    }
  }, [initialValue, open]);

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="sm">
      <DialogTitle>{initialValue ? 'Edit category' : 'Create category'}</DialogTitle>
      <DialogContent>
        <Stack spacing={2} mt={1}>
          <TextField
            label="Category name"
            value={form.name}
            onChange={(event) => setForm((prev) => ({ ...prev, name: event.target.value }))}
            fullWidth
          />
          <TextField
            select
            label="Type"
            value={form.type}
            onChange={(event) =>
              setForm((prev) => ({ ...prev, type: event.target.value as CategoryType }))
            }
            fullWidth
          >
            <MenuItem value="EXPENSE">Expense</MenuItem>
            <MenuItem value="INCOME">Income</MenuItem>
          </TextField>
          <TextField
            label="Color"
            value={form.color}
            onChange={(event) => setForm((prev) => ({ ...prev, color: event.target.value }))}
            fullWidth
          />
          <TextField
            label="Icon"
            value={form.icon}
            onChange={(event) => setForm((prev) => ({ ...prev, icon: event.target.value }))}
            fullWidth
          />
        </Stack>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={() => void onSubmit(form)}>
          Save
        </Button>
      </DialogActions>
    </Dialog>
  );
}
