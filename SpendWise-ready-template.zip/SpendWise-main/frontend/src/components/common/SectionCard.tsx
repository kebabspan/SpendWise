import { Card, CardContent, Stack, Typography, type SxProps, type Theme } from '@mui/material';
import type { PropsWithChildren } from 'react';

interface SectionCardProps extends PropsWithChildren {
  title?: string;
  subtitle?: string;
  sx?: SxProps<Theme>;
}

export default function SectionCard({ title, subtitle, sx, children }: SectionCardProps) {
  return (
    <Card
      sx={{
        borderRadius: 4,
        boxShadow: '0 20px 45px rgba(15, 23, 42, 0.06)',
        ...sx,
      }}
    >
      <CardContent>
        {title ? (
          <Stack spacing={0.5} mb={2.5}>
            <Typography variant="h6" fontWeight={700}>
              {title}
            </Typography>
            {subtitle ? (
              <Typography variant="body2" color="text.secondary">
                {subtitle}
              </Typography>
            ) : null}
          </Stack>
        ) : null}
        {children}
      </CardContent>
    </Card>
  );
}
