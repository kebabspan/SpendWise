import InboxOutlinedIcon from '@mui/icons-material/InboxOutlined';
import { Button, Stack, Typography } from '@mui/material';

interface EmptyStateProps {
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
}

export default function EmptyState({ title, description, actionLabel, onAction }: EmptyStateProps) {
  return (
    <Stack alignItems="center" textAlign="center" spacing={1.5} py={6}>
      <InboxOutlinedIcon color="disabled" sx={{ fontSize: 48 }} />
      <Typography variant="h6" fontWeight={700}>
        {title}
      </Typography>
      <Typography variant="body2" color="text.secondary" maxWidth={420}>
        {description}
      </Typography>
      {actionLabel ? (
        <Button variant="contained" onClick={onAction} sx={{ mt: 1, borderRadius: 999 }}>
          {actionLabel}
        </Button>
      ) : null}
    </Stack>
  );
}
