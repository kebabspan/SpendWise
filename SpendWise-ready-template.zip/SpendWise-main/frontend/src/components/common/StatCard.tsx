import { Card, CardContent, Chip, Stack, Typography } from '@mui/material';
import type { ReactNode } from 'react';

interface StatCardProps {
  icon: ReactNode;
  label: string;
  value: string;
  helper: string;
}

export default function StatCard({ icon, label, value, helper }: StatCardProps) {
  return (
    <Card
      sx={{
        borderRadius: 4,
        background: 'linear-gradient(180deg, rgba(255,255,255,1), rgba(248,250,252,1))',
        boxShadow: '0 20px 45px rgba(15, 23, 42, 0.05)',
        height: '100%',
      }}
    >
      <CardContent>
        <Stack spacing={2}>
          <Stack direction="row" justifyContent="space-between" alignItems="center">
            <Chip label={label} size="small" color="primary" variant="outlined" />
            {icon}
          </Stack>
          <Typography variant="h4" fontWeight={800}>
            {value}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {helper}
          </Typography>
        </Stack>
      </CardContent>
    </Card>
  );
}
