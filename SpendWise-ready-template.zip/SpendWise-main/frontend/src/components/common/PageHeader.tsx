import { Box, Button, Stack, Typography } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';

interface PageHeaderProps {
  eyebrow?: string;
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
  actionDisabled?: boolean;
}

export default function PageHeader({
  eyebrow,
  title,
  description,
  actionLabel,
  onAction,
  actionDisabled,
}: PageHeaderProps) {
  return (
    <Stack
      direction={{ xs: 'column', md: 'row' }}
      justifyContent="space-between"
      alignItems={{ xs: 'flex-start', md: 'center' }}
      spacing={2}
    >
      <Box>
        {eyebrow ? (
          <Typography variant="overline" color="primary" fontWeight={700}>
            {eyebrow}
          </Typography>
        ) : null}
        <Typography variant="h4" fontWeight={800} gutterBottom>
          {title}
        </Typography>
        <Typography variant="body1" color="text.secondary">
          {description}
        </Typography>
      </Box>

      {actionLabel ? (
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={onAction}
          disabled={actionDisabled}
          sx={{ borderRadius: 999 }}
        >
          {actionLabel}
        </Button>
      ) : null}
    </Stack>
  );
}
