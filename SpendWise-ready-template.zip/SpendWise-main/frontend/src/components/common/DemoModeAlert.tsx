import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import { Alert, Link, Stack, Typography } from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';

export default function DemoModeAlert() {
  return (
    <Alert icon={<InfoOutlinedIcon fontSize="inherit" />} severity="info" sx={{ borderRadius: 3 }}>
      <Stack spacing={0.5}>
        <Typography fontWeight={700}>Demo mode is active.</Typography>
        <Typography variant="body2">
          The dashboard is fully navigable, but data changes are disabled until you{' '}
          <Link component={RouterLink} to="/login" sx={{ fontWeight: 700 }}>
            sign in
          </Link>
          .
        </Typography>
      </Stack>
    </Alert>
  );
}
