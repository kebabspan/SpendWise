import type { Account } from './account';
import type { Category } from './category';

export type TransactionType = 'EXPENSE' | 'INCOME' | 'TRANSFER';

export interface Transaction {
  id: string;
  amount: number | string;
  note?: string | null;
  description?: string | null;
  place?: string | null;
  date: string;
  type: TransactionType;
  categoryId?: string | null;
  category?: Category | null;
  fromAccountId?: string | null;
  fromAccount?: Account | null;
  toAccountId?: string | null;
  toAccount?: Account | null;
}

export interface TransactionPayload {
  amount: number;
  description?: string;
  place?: string;
  date?: string;
  type: TransactionType;
  categoryId?: string;
  accountId: string;
  toAccountId?: string;
}
