export type CategoryType = 'INCOME' | 'EXPENSE';

export interface Category {
  id: string;
  name: string;
  type: CategoryType;
  color?: string | null;
  icon?: string | null;
}

export interface CategoryPayload {
  name: string;
  type: CategoryType;
  color?: string;
  icon?: string;
}
