export interface Account {
  id: string;
  name: string;
  balance: number | string;
  color?: string | null;
  icon?: string | null;
  createdAt?: string;
  updatedAt?: string;
}

export interface AccountPayload {
  name: string;
  balance?: number;
  color?: string;
  icon?: string;
}
