import type { Category } from './category';

export interface Budget {
  id: string;
  limitAmount: number | string;
  month: number;
  year: number;
  categoryId: string;
  category?: Category;
}

export interface BudgetPayload {
  limitAmount: number;
  month: number;
  year: number;
  categoryId: string;
}
