export interface UserProfile {
  id: string;
  email: string;
  name?: string | null;
  currency?: string | null;
  imageUrl?: string | null;
  createdAt?: string;
}

export interface UpdateUserPayload {
  name?: string;
  password?: string;
  currency?: string;
  imageUrl?: string;
}
