import type { Account } from '../types/account';
import type { Budget } from '../types/budget';
import type { Category } from '../types/category';
import type { Transaction } from '../types/transaction';
import type { UserProfile } from '../types/user';

export const siteConfig = {
  appName: 'SpendWise',
  tagline: 'Personal finance dashboard template',
  heroTitle: 'Track every forint with a clean Material UI dashboard.',
  heroDescription:
    'This frontend is already wired to your SpendWise backend structure. You only need to rename the texts, colors, and branding to match your final project.',
  primaryActionLabel: 'Open dashboard',
  secondaryActionLabel: 'Connect backend',
};

export const demoProfile: UserProfile = {
  id: 'demo-user',
  email: 'demo@spendwise.app',
  name: 'Demo User',
  currency: 'HUF',
  imageUrl: '',
  createdAt: new Date().toISOString(),
};

export const demoAccounts: Account[] = [
  { id: 'acc-1', name: 'Main Bank', balance: 328450, color: '#1976d2', icon: 'account_balance' },
  { id: 'acc-2', name: 'Savings Jar', balance: 1260000, color: '#7b1fa2', icon: 'savings' },
  { id: 'acc-3', name: 'Cash Wallet', balance: 25500, color: '#2e7d32', icon: 'payments' },
];

export const demoCategories: Category[] = [
  { id: 'cat-1', name: 'Groceries', type: 'EXPENSE', color: '#ef5350', icon: 'shopping_cart' },
  { id: 'cat-2', name: 'Utilities', type: 'EXPENSE', color: '#fb8c00', icon: 'bolt' },
  { id: 'cat-3', name: 'Salary', type: 'INCOME', color: '#43a047', icon: 'payments' },
  { id: 'cat-4', name: 'Transport', type: 'EXPENSE', color: '#1e88e5', icon: 'directions_car' },
];

export const demoBudgets: Budget[] = [
  {
    id: 'budget-1',
    categoryId: 'cat-1',
    limitAmount: 120000,
    month: new Date().getMonth() + 1,
    year: new Date().getFullYear(),
    category: demoCategories[0],
  },
  {
    id: 'budget-2',
    categoryId: 'cat-2',
    limitAmount: 45000,
    month: new Date().getMonth() + 1,
    year: new Date().getFullYear(),
    category: demoCategories[1],
  },
];

export const demoTransactions: Transaction[] = [
  {
    id: 'txn-1',
    amount: 18500,
    description: 'Weekly grocery refill',
    place: 'Tesco',
    date: new Date().toISOString(),
    type: 'EXPENSE',
    categoryId: 'cat-1',
    category: demoCategories[0],
    fromAccountId: 'acc-1',
    fromAccount: demoAccounts[0],
  },
  {
    id: 'txn-2',
    amount: 420000,
    description: 'Monthly salary',
    place: 'Employer transfer',
    date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2).toISOString(),
    type: 'INCOME',
    categoryId: 'cat-3',
    category: demoCategories[2],
    fromAccountId: 'acc-1',
    fromAccount: demoAccounts[0],
  },
  {
    id: 'txn-3',
    amount: 12000,
    description: 'Fuel refill',
    place: 'Shell',
    date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 4).toISOString(),
    type: 'EXPENSE',
    categoryId: 'cat-4',
    category: demoCategories[3],
    fromAccountId: 'acc-1',
    fromAccount: demoAccounts[0],
  },
];
