import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type PropsWithChildren,
} from 'react';
import { authService } from '../services/auth.service';
import { userService } from '../services/user.service';
import { storage } from '../lib/storage';
import { demoProfile } from '../lib/site';
import type { AuthUser, LoginPayload, RegisterPayload } from '../types/auth';
import type { UpdateUserPayload, UserProfile } from '../types/user';

interface AuthContextValue {
  token: string | null;
  user: UserProfile | null;
  authUser: AuthUser | null;
  isAuthenticated: boolean;
  isDemoMode: boolean;
  login: (payload: LoginPayload) => Promise<void>;
  register: (payload: RegisterPayload) => Promise<void>;
  logout: () => void;
  refreshProfile: () => Promise<void>;
  updateProfile: (payload: UpdateUserPayload) => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: PropsWithChildren) {
  const [token, setToken] = useState<string | null>(() => storage.getToken());
  const [authUser, setAuthUser] = useState<AuthUser | null>(() => storage.getUser<AuthUser>());
  const [user, setUser] = useState<UserProfile | null>(token ? null : demoProfile);

  const logout = useCallback(() => {
    storage.clearAll();
    setToken(null);
    setAuthUser(null);
    setUser(demoProfile);
  }, []);

  const refreshProfile = useCallback(async () => {
    if (!storage.getToken()) {
      setUser(demoProfile);
      return;
    }
    try {
      const profile = await userService.getMe();
      setUser(profile);
    } catch (error) {
      console.error(error);
      logout();
    }
  }, [logout]);

  const login = useCallback(async (payload: LoginPayload) => {
    const result = await authService.login(payload);
    storage.setToken(result.access_token);
    storage.setUser(result.user);
    setToken(result.access_token);
    setAuthUser(result.user);
    const profile = await userService.getMe();
    setUser(profile);
  }, []);

  const register = useCallback(async (payload: RegisterPayload) => {
    await authService.register(payload);
    await login({ email: payload.email, password: payload.password });
  }, [login]);

  const updateProfile = useCallback(async (payload: UpdateUserPayload) => {
    const updated = await userService.update(payload);
    setUser((prev) => ({ ...prev, ...updated }));
  }, []);

  useEffect(() => {
    if (token) {
      refreshProfile();
    }
  }, [token, refreshProfile]);

  const value = useMemo<AuthContextValue>(
    () => ({
      token,
      user,
      authUser,
      isAuthenticated: Boolean(token),
      isDemoMode: !token,
      login,
      register,
      logout,
      refreshProfile,
      updateProfile,
    }),
    [token, user, authUser, login, register, logout, refreshProfile, updateProfile],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used inside AuthProvider');
  }
  return context;
};
