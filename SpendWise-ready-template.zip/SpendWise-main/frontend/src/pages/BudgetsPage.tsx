import {
  Alert,
  IconButton,
  LinearProgress,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Tooltip,
  Typography,
} from '@mui/material';
import DeleteRoundedIcon from '@mui/icons-material/DeleteRounded';
import { useEffect, useMemo, useState } from 'react';
import EmptyState from '../components/common/EmptyState';
import PageHeader from '../components/common/PageHeader';
import SectionCard from '../components/common/SectionCard';
import BudgetDialog from '../components/forms/BudgetDialog';
import { useAuth } from '../context/AuthContext';
import { formatCurrency, toNumber } from '../lib/format';
import { demoBudgets, demoCategories, demoTransactions } from '../lib/site';
import { budgetsService } from '../services/budgets.service';
import { categoriesService } from '../services/categories.service';
import { transactionsService } from '../services/transactions.service';
import type { Budget } from '../types/budget';
import type { Category } from '../types/category';
import type { Transaction } from '../types/transaction';

export default function BudgetsPage() {
  const { isDemoMode, user } = useAuth();
  const [budgets, setBudgets] = useState<Budget[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);

  const loadData = async () => {
    if (isDemoMode) {
      setBudgets(demoBudgets);
      setCategories(demoCategories);
      setTransactions(demoTransactions);
      return;
    }

    const [budgetsData, categoriesData, transactionsData] = await Promise.all([
      budgetsService.getAll(),
      categoriesService.getAll(),
      transactionsService.getAll(),
    ]);
    setBudgets(budgetsData);
    setCategories(categoriesData);
    setTransactions(transactionsData);
  };

  useEffect(() => {
    void loadData();
  }, [isDemoMode]);

  const expenseByCategory = useMemo(() => {
    return transactions.reduce<Record<string, number>>((acc, transaction) => {
      if (transaction.type === 'EXPENSE' && transaction.categoryId) {
        acc[transaction.categoryId] = (acc[transaction.categoryId] || 0) + toNumber(transaction.amount);
      }
      return acc;
    }, {});
  }, [transactions]);

  const handleCreate = async (payload: {
    limitAmount: number;
    month: number;
    year: number;
    categoryId: string;
  }) => {
    if (isDemoMode) {
      setDialogOpen(false);
      return;
    }
    await budgetsService.create(payload);
    setDialogOpen(false);
    await loadData();
  };

  const handleDelete = async (id: string) => {
    if (isDemoMode) return;
    await budgetsService.remove(id);
    await loadData();
  };

  return (
    <Stack spacing={3}>
      {isDemoMode ? <Alert severity="info">Budget changes are disabled in demo mode.</Alert> : null}

      <PageHeader
        eyebrow="Planning"
        title="Budgets"
        description="Expense ceilings linked to category IDs, exactly as your backend expects them."
        actionLabel="New budget"
        onAction={() => setDialogOpen(true)}
      />

      <SectionCard>
        {budgets.length === 0 ? (
          <EmptyState
            title="No budgets configured"
            description="Create a budget to compare spending against a monthly limit."
            actionLabel="Create budget"
            onAction={() => setDialogOpen(true)}
          />
        ) : (
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Category</TableCell>
                <TableCell>Period</TableCell>
                <TableCell>Limit</TableCell>
                <TableCell>Spent</TableCell>
                <TableCell>Progress</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {budgets.map((budget) => {
                const spent = expenseByCategory[budget.categoryId] || 0;
                const limit = toNumber(budget.limitAmount);
                const progress = limit ? Math.min((spent / limit) * 100, 100) : 0;
                const categoryName = budget.category?.name || categories.find((item) => item.id === budget.categoryId)?.name;

                return (
                  <TableRow key={budget.id} hover>
                    <TableCell>
                      <Typography fontWeight={700}>{categoryName || 'Unknown category'}</Typography>
                    </TableCell>
                    <TableCell>
                      {budget.year}.{String(budget.month).padStart(2, '0')}
                    </TableCell>
                    <TableCell>{formatCurrency(limit, user?.currency || 'HUF')}</TableCell>
                    <TableCell>{formatCurrency(spent, user?.currency || 'HUF')}</TableCell>
                    <TableCell sx={{ minWidth: 220 }}>
                      <Stack spacing={0.8}>
                        <LinearProgress variant="determinate" value={progress} sx={{ height: 10, borderRadius: 999 }} />
                        <Typography variant="caption" color="text.secondary">
                          {progress.toFixed(0)}% used
                        </Typography>
                      </Stack>
                    </TableCell>
                    <TableCell align="right">
                      <Tooltip title="Delete">
                        <span>
                          <IconButton disabled={isDemoMode} onClick={() => void handleDelete(budget.id)}>
                            <DeleteRoundedIcon />
                          </IconButton>
                        </span>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        )}
      </SectionCard>

      <BudgetDialog
        open={dialogOpen}
        categories={categories}
        onClose={() => setDialogOpen(false)}
        onSubmit={handleCreate}
      />
    </Stack>
  );
}
