import { Alert, Avatar, Box, Button, Stack, TextField, Typography } from '@mui/material';
import { useEffect, useState } from 'react';
import PageHeader from '../components/common/PageHeader';
import SectionCard from '../components/common/SectionCard';
import { useAuth } from '../context/AuthContext';
import { formatDate } from '../lib/format';

export default function ProfilePage() {
  const { isDemoMode, user, updateProfile } = useAuth();
  const [name, setName] = useState(user?.name || '');
  const [currency, setCurrency] = useState(user?.currency || 'HUF');
  const [imageUrl, setImageUrl] = useState(user?.imageUrl || '');
  const [password, setPassword] = useState('');
  const [savedMessage, setSavedMessage] = useState('');

  useEffect(() => {
    setName(user?.name || '');
    setCurrency(user?.currency || 'HUF');
    setImageUrl(user?.imageUrl || '');
  }, [user]);

  const handleSave = async () => {
    if (isDemoMode) return;
    await updateProfile({
      name,
      currency,
      imageUrl,
      password: password || undefined,
    });
    setPassword('');
    setSavedMessage('Profile updated successfully.');
  };

  return (
    <Stack spacing={3}>
      {isDemoMode ? <Alert severity="info">Profile updates are disabled in demo mode.</Alert> : null}
      {savedMessage ? <Alert severity="success">{savedMessage}</Alert> : null}

      <PageHeader
        eyebrow="User settings"
        title="Profile"
        description="This page already matches the user/me and user/update backend endpoints."
      />

      <Box
        sx={{
          display: 'grid',
          gap: 2.5,
          gridTemplateColumns: { xs: '1fr', lg: 'minmax(0, 0.85fr) minmax(0, 1.4fr)' },
        }}
      >
        <Box>
          <SectionCard title="Identity" subtitle="Basic user details from the backend profile endpoint">
            <Stack spacing={2} alignItems="center" textAlign="center">
              <Avatar src={user?.imageUrl || undefined} sx={{ width: 92, height: 92 }}>
                {(user?.name || 'U').charAt(0)}
              </Avatar>
              <Typography variant="h5" fontWeight={800}>
                {user?.name || 'Unnamed user'}
              </Typography>
              <Typography color="text.secondary">{user?.email}</Typography>
              <Typography variant="body2" color="text.secondary">
                Member since {formatDate(user?.createdAt)}
              </Typography>
            </Stack>
          </SectionCard>
        </Box>
        <Box>
          <SectionCard title="Edit profile" subtitle="Change names, currency, avatar URL, or password">
            <Stack spacing={2}>
              <TextField label="Display name" value={name} onChange={(event) => setName(event.target.value)} fullWidth />
              <TextField label="Currency" value={currency} onChange={(event) => setCurrency(event.target.value)} fullWidth />
              <TextField label="Image URL" value={imageUrl} onChange={(event) => setImageUrl(event.target.value)} fullWidth />
              <TextField
                label="New password"
                type="password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                helperText="Leave empty if you do not want to change it."
                fullWidth
              />
              <Button variant="contained" onClick={() => void handleSave()} disabled={isDemoMode} sx={{ alignSelf: 'flex-start', borderRadius: 999 }}>
                Save changes
              </Button>
            </Stack>
          </SectionCard>
        </Box>
      </Box>
    </Stack>
  );
}
