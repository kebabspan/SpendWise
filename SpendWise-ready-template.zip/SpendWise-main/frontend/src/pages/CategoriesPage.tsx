import {
  Alert,
  Chip,
  IconButton,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Tooltip,
  Typography,
} from '@mui/material';
import DeleteRoundedIcon from '@mui/icons-material/DeleteRounded';
import EditRoundedIcon from '@mui/icons-material/EditRounded';
import { useEffect, useState } from 'react';
import EmptyState from '../components/common/EmptyState';
import PageHeader from '../components/common/PageHeader';
import SectionCard from '../components/common/SectionCard';
import CategoryDialog from '../components/forms/CategoryDialog';
import { useAuth } from '../context/AuthContext';
import { demoCategories } from '../lib/site';
import { categoriesService } from '../services/categories.service';
import type { Category, CategoryPayload } from '../types/category';

export default function CategoriesPage() {
  const { isDemoMode } = useAuth();
  const [categories, setCategories] = useState<Category[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Category | null>(null);

  const loadCategories = async () => {
    if (isDemoMode) {
      setCategories(demoCategories);
      return;
    }
    setCategories(await categoriesService.getAll());
  };

  useEffect(() => {
    void loadCategories();
  }, [isDemoMode]);

  const handleSave = async (payload: CategoryPayload) => {
    if (isDemoMode) {
      setDialogOpen(false);
      return;
    }
    if (editing) {
      await categoriesService.update(editing.id, payload);
    } else {
      await categoriesService.create(payload);
    }
    setDialogOpen(false);
    setEditing(null);
    await loadCategories();
  };

  const handleDelete = async (id: string) => {
    if (isDemoMode) return;
    await categoriesService.remove(id);
    await loadCategories();
  };

  return (
    <Stack spacing={3}>
      {isDemoMode ? <Alert severity="info">Category changes are disabled in demo mode.</Alert> : null}

      <PageHeader
        eyebrow="Classification"
        title="Categories"
        description="Fully aligned with the backend category DTO: name, type, color, and icon."
        actionLabel="New category"
        onAction={() => {
          setEditing(null);
          setDialogOpen(true);
        }}
      />

      <SectionCard>
        {categories.length === 0 ? (
          <EmptyState
            title="No categories found"
            description="Create income and expense categories before adding live transactions."
            actionLabel="Create category"
            onAction={() => setDialogOpen(true)}
          />
        ) : (
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Name</TableCell>
                <TableCell>Type</TableCell>
                <TableCell>Icon</TableCell>
                <TableCell>Color</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {categories.map((category) => (
                <TableRow key={category.id} hover>
                  <TableCell>
                    <Typography fontWeight={700}>{category.name}</Typography>
                  </TableCell>
                  <TableCell>
                    <Chip
                      size="small"
                      label={category.type}
                      color={category.type === 'EXPENSE' ? 'error' : 'success'}
                      variant="outlined"
                    />
                  </TableCell>
                  <TableCell>{category.icon || '—'}</TableCell>
                  <TableCell>
                    <Stack direction="row" spacing={1} alignItems="center">
                      <Stack
                        sx={{ width: 14, height: 14, borderRadius: '50%', bgcolor: category.color || '#cbd5e1' }}
                      />
                      <Typography variant="body2">{category.color || 'Default'}</Typography>
                    </Stack>
                  </TableCell>
                  <TableCell align="right">
                    <Tooltip title="Edit">
                      <IconButton
                        onClick={() => {
                          setEditing(category);
                          setDialogOpen(true);
                        }}
                      >
                        <EditRoundedIcon />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Delete">
                      <span>
                        <IconButton disabled={isDemoMode} onClick={() => void handleDelete(category.id)}>
                          <DeleteRoundedIcon />
                        </IconButton>
                      </span>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </SectionCard>

      <CategoryDialog
        open={dialogOpen}
        initialValue={editing}
        onClose={() => {
          setDialogOpen(false);
          setEditing(null);
        }}
        onSubmit={handleSave}
      />
    </Stack>
  );
}
