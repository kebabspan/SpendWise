import {
  Alert,
  Box,
  Button,
  Card,
  Link,
  Stack,
  TextField,
  Typography,
} from '@mui/material';
import { useState } from 'react';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { siteConfig } from '../lib/site';

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async () => {
    try {
      setError('');
      await login({ email, password });
      navigate('/');
    } catch (err) {
      console.error(err);
      setError('Login failed. Check the backend URL and your credentials.');
    }
  };

  return (
    <Box sx={{ minHeight: '100vh', display: 'grid', placeItems: 'center', p: 2 }} className="page-gradient">
      <Card sx={{ width: '100%', maxWidth: 460, borderRadius: 5, p: 4, boxShadow: '0 24px 70px rgba(15, 23, 42, 0.12)' }}>
        <Stack spacing={2.5}>
          <Box>
            <Typography variant="overline" color="primary" fontWeight={800}>
              {siteConfig.appName}
            </Typography>
            <Typography variant="h4" fontWeight={900}>
              Sign in
            </Typography>
            <Typography color="text.secondary">Connect the template to your real SpendWise data.</Typography>
          </Box>
          {error ? <Alert severity="error">{error}</Alert> : null}
          <TextField label="Email" type="email" value={email} onChange={(event) => setEmail(event.target.value)} fullWidth />
          <TextField label="Password" type="password" value={password} onChange={(event) => setPassword(event.target.value)} fullWidth />
          <Button variant="contained" size="large" onClick={() => void handleSubmit()} sx={{ borderRadius: 999 }}>
            Sign in
          </Button>
          <Typography variant="body2" color="text.secondary">
            No account yet?{' '}
            <Link component={RouterLink} to="/register" sx={{ fontWeight: 700 }}>
              Create one here.
            </Link>
          </Typography>
          <Typography variant="caption" color="text.secondary">
            Backend default: <strong>VITE_API_URL=http://localhost:3001/api</strong>
          </Typography>
        </Stack>
      </Card>
    </Box>
  );
}
