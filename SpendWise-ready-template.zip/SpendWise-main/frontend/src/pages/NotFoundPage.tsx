import { Box, Button, Stack, Typography } from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';

export default function NotFoundPage() {
  return (
    <Box sx={{ minHeight: '100vh', display: 'grid', placeItems: 'center', p: 2 }}>
      <Stack spacing={2} textAlign="center" alignItems="center">
        <Typography variant="h2" fontWeight={900}>
          404
        </Typography>
        <Typography variant="h5" fontWeight={800}>
          Page not found
        </Typography>
        <Typography color="text.secondary" maxWidth={420}>
          This route is not configured yet. You can rename or replace it later inside the frontend pages folder.
        </Typography>
        <Button component={RouterLink} to="/" variant="contained" sx={{ borderRadius: 999 }}>
          Back to dashboard
        </Button>
      </Stack>
    </Box>
  );
}
