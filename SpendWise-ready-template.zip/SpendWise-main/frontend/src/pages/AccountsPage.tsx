import {
  Alert,
  Button,
  IconButton,
  Stack,
  Tooltip,
  Typography,
} from '@mui/material';
import EditRoundedIcon from '@mui/icons-material/EditRounded';
import DeleteRoundedIcon from '@mui/icons-material/DeleteRounded';
import { useEffect, useState } from 'react';
import EmptyState from '../components/common/EmptyState';
import PageHeader from '../components/common/PageHeader';
import SectionCard from '../components/common/SectionCard';
import AccountDialog from '../components/forms/AccountDialog';
import { useAuth } from '../context/AuthContext';
import { formatCurrency } from '../lib/format';
import { demoAccounts } from '../lib/site';
import { accountsService } from '../services/accounts.service';
import type { Account } from '../types/account';

export default function AccountsPage() {
  const { isDemoMode, user } = useAuth();
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Account | null>(null);

  const loadAccounts = async () => {
    if (isDemoMode) {
      setAccounts(demoAccounts);
      return;
    }
    setAccounts(await accountsService.getAll());
  };

  useEffect(() => {
    void loadAccounts();
  }, [isDemoMode]);

  const handleSave = async (payload: {
    name: string;
    balance: number;
    color?: string;
    icon?: string;
  }) => {
    if (isDemoMode) {
      setDialogOpen(false);
      return;
    }

    if (editing) {
      await accountsService.update(editing.id, payload);
    } else {
      await accountsService.create(payload);
    }

    setDialogOpen(false);
    setEditing(null);
    await loadAccounts();
  };

  const handleDelete = async (id: string) => {
    if (isDemoMode) return;
    await accountsService.remove(id);
    await loadAccounts();
  };

  return (
    <Stack spacing={3}>
      {isDemoMode ? <Alert severity="info">Account mutations are disabled in demo mode.</Alert> : null}

      <PageHeader
        eyebrow="Finance structure"
        title="Accounts"
        description="Bank accounts, wallets, and savings containers connected to the backend accounts module."
        actionLabel="New account"
        onAction={() => {
          setEditing(null);
          setDialogOpen(true);
        }}
      />

      {accounts.length === 0 ? (
        <SectionCard>
          <EmptyState
            title="No accounts yet"
            description="Create your first account to start managing balances and transactions."
            actionLabel="Create account"
            onAction={() => setDialogOpen(true)}
          />
        </SectionCard>
      ) : (
        <Stack
          sx={{
            display: 'grid',
            gap: 2.5,
            gridTemplateColumns: { xs: '1fr', md: 'repeat(2, 1fr)', xl: 'repeat(3, 1fr)' },
          }}
        >
          {accounts.map((account) => (
            <SectionCard key={account.id}>
              <Stack spacing={2}>
                <Stack direction="row" justifyContent="space-between" alignItems="center">
                  <Stack>
                    <Typography variant="h6" fontWeight={800}>
                      {account.name}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {account.icon || 'Custom icon'}
                    </Typography>
                  </Stack>
                  <Stack direction="row">
                    <Tooltip title="Edit">
                      <IconButton
                        onClick={() => {
                          setEditing(account);
                          setDialogOpen(true);
                        }}
                      >
                        <EditRoundedIcon />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Delete">
                      <span>
                        <IconButton disabled={isDemoMode} onClick={() => void handleDelete(account.id)}>
                          <DeleteRoundedIcon />
                        </IconButton>
                      </span>
                    </Tooltip>
                  </Stack>
                </Stack>
                <Typography variant="h4" fontWeight={900}>
                  {formatCurrency(account.balance, user?.currency || 'HUF')}
                </Typography>
                <Button
                  variant="outlined"
                  onClick={() => {
                    setEditing(account);
                    setDialogOpen(true);
                  }}
                  sx={{ alignSelf: 'flex-start', borderRadius: 999 }}
                >
                  Customize card
                </Button>
              </Stack>
            </SectionCard>
          ))}
        </Stack>
      )}

      <AccountDialog
        open={dialogOpen}
        initialValue={editing}
        onClose={() => {
          setDialogOpen(false);
          setEditing(null);
        }}
        onSubmit={handleSave}
      />
    </Stack>
  );
}
