import {
  Alert,
  Chip,
  IconButton,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Tooltip,
  Typography,
} from '@mui/material';
import DeleteRoundedIcon from '@mui/icons-material/DeleteRounded';
import { useEffect, useState } from 'react';
import EmptyState from '../components/common/EmptyState';
import PageHeader from '../components/common/PageHeader';
import SectionCard from '../components/common/SectionCard';
import TransactionDialog from '../components/forms/TransactionDialog';
import { useAuth } from '../context/AuthContext';
import { formatCurrency, formatDate } from '../lib/format';
import { demoAccounts, demoCategories, demoTransactions } from '../lib/site';
import { accountsService } from '../services/accounts.service';
import { categoriesService } from '../services/categories.service';
import { transactionsService } from '../services/transactions.service';
import type { Account } from '../types/account';
import type { Category } from '../types/category';
import type { Transaction, TransactionPayload } from '../types/transaction';

export default function TransactionsPage() {
  const { isDemoMode, user } = useAuth();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);

  const loadData = async () => {
    if (isDemoMode) {
      setTransactions(demoTransactions);
      setAccounts(demoAccounts);
      setCategories(demoCategories);
      return;
    }

    const [transactionsData, accountsData, categoriesData] = await Promise.all([
      transactionsService.getAll(),
      accountsService.getAll(),
      categoriesService.getAll(),
    ]);

    setTransactions(transactionsData);
    setAccounts(accountsData);
    setCategories(categoriesData);
  };

  useEffect(() => {
    void loadData();
  }, [isDemoMode]);

  const handleCreate = async (payload: TransactionPayload) => {
    if (isDemoMode) {
      setDialogOpen(false);
      return;
    }
    await transactionsService.create(payload);
    setDialogOpen(false);
    await loadData();
  };

  const handleDelete = async (id: string) => {
    if (isDemoMode) return;
    await transactionsService.remove(id);
    await loadData();
  };

  return (
    <Stack spacing={3}>
      {isDemoMode ? <Alert severity="info">Transaction changes are disabled in demo mode.</Alert> : null}

      <PageHeader
        eyebrow="Money flow"
        title="Transactions"
        description="Uses the backend transaction DTO fields: amount, description, place, date, type, categoryId, accountId and toAccountId."
        actionLabel="New transaction"
        onAction={() => setDialogOpen(true)}
      />

      <SectionCard>
        {transactions.length === 0 ? (
          <EmptyState
            title="No transactions yet"
            description="Add expense, income or transfer entries to populate the dashboard feed."
            actionLabel="Create transaction"
            onAction={() => setDialogOpen(true)}
          />
        ) : (
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Date</TableCell>
                <TableCell>Description</TableCell>
                <TableCell>Type</TableCell>
                <TableCell>Category</TableCell>
                <TableCell>Account</TableCell>
                <TableCell align="right">Amount</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {transactions.map((transaction) => (
                <TableRow key={transaction.id} hover>
                  <TableCell>{formatDate(transaction.date)}</TableCell>
                  <TableCell>
                    <Typography fontWeight={700}>
                      {transaction.description || transaction.note || 'Untitled transaction'}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {transaction.place || 'No location'}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Chip
                      size="small"
                      label={transaction.type}
                      color={transaction.type === 'EXPENSE' ? 'error' : transaction.type === 'INCOME' ? 'success' : 'info'}
                      variant="outlined"
                    />
                  </TableCell>
                  <TableCell>{transaction.category?.name || '—'}</TableCell>
                  <TableCell>
                    {transaction.fromAccount?.name ||
                      accounts.find((account) => account.id === transaction.fromAccountId)?.name ||
                      '—'}
                  </TableCell>
                  <TableCell align="right">
                    <Typography fontWeight={800}>
                      {formatCurrency(transaction.amount, user?.currency || 'HUF')}
                    </Typography>
                  </TableCell>
                  <TableCell align="right">
                    <Tooltip title="Delete">
                      <span>
                        <IconButton disabled={isDemoMode} onClick={() => void handleDelete(transaction.id)}>
                          <DeleteRoundedIcon />
                        </IconButton>
                      </span>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </SectionCard>

      <TransactionDialog
        open={dialogOpen}
        accounts={accounts}
        categories={categories}
        onClose={() => setDialogOpen(false)}
        onSubmit={handleCreate}
      />
    </Stack>
  );
}
