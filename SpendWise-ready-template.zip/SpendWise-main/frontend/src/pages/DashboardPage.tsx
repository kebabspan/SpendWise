import {
  Avatar,
  Box,
  Chip,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Stack,
  Typography,
} from '@mui/material';
import AccountBalanceWalletRoundedIcon from '@mui/icons-material/AccountBalanceWalletRounded';
import TrendingDownRoundedIcon from '@mui/icons-material/TrendingDownRounded';
import TrendingUpRoundedIcon from '@mui/icons-material/TrendingUpRounded';
import SavingsRoundedIcon from '@mui/icons-material/SavingsRounded';
import { useEffect, useMemo, useState } from 'react';
import DemoModeAlert from '../components/common/DemoModeAlert';
import PageHeader from '../components/common/PageHeader';
import SectionCard from '../components/common/SectionCard';
import StatCard from '../components/common/StatCard';
import { useAuth } from '../context/AuthContext';
import { demoAccounts, demoBudgets, demoTransactions, siteConfig } from '../lib/site';
import { formatCurrency, formatDate, toNumber } from '../lib/format';
import { accountsService } from '../services/accounts.service';
import { budgetsService } from '../services/budgets.service';
import { transactionsService } from '../services/transactions.service';
import type { Account } from '../types/account';
import type { Budget } from '../types/budget';
import type { Transaction } from '../types/transaction';

export default function DashboardPage() {
  const { isDemoMode, user } = useAuth();
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [budgets, setBudgets] = useState<Budget[]>([]);

  useEffect(() => {
    if (isDemoMode) {
      setAccounts(demoAccounts);
      setTransactions(demoTransactions);
      setBudgets(demoBudgets);
      return;
    }

    void Promise.all([
      accountsService.getAll(),
      transactionsService.getAll(),
      budgetsService.getAll(),
    ]).then(([accountsData, transactionsData, budgetsData]) => {
      setAccounts(accountsData);
      setTransactions(transactionsData);
      setBudgets(budgetsData);
    });
  }, [isDemoMode]);

  const totalBalance = useMemo(
    () => accounts.reduce((sum, account) => sum + toNumber(account.balance), 0),
    [accounts],
  );

  const monthlyExpense = useMemo(
    () =>
      transactions
        .filter((transaction) => transaction.type === 'EXPENSE')
        .reduce((sum, transaction) => sum + toNumber(transaction.amount), 0),
    [transactions],
  );

  const monthlyIncome = useMemo(
    () =>
      transactions
        .filter((transaction) => transaction.type === 'INCOME')
        .reduce((sum, transaction) => sum + toNumber(transaction.amount), 0),
    [transactions],
  );

  const budgetLimit = useMemo(
    () => budgets.reduce((sum, budget) => sum + toNumber(budget.limitAmount), 0),
    [budgets],
  );

  return (
    <Stack spacing={3}>
      {isDemoMode ? <DemoModeAlert /> : null}

      <PageHeader
        eyebrow="Template overview"
        title={`${siteConfig.appName} dashboard`}
        description={`Welcome${user?.name ? `, ${user.name}` : ''}. The page already uses the SpendWise backend entity structure, so you can now focus on renaming labels and polishing content.`}
      />

      <Box
        sx={{
          display: 'grid',
          gap: 2.5,
          gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)', xl: 'repeat(4, 1fr)' },
        }}
      >
        <StatCard
          icon={<AccountBalanceWalletRoundedIcon color="primary" />}
          label="Total balance"
          value={formatCurrency(totalBalance, user?.currency || 'HUF')}
          helper="All connected accounts combined."
        />
        <StatCard
          icon={<TrendingDownRoundedIcon color="error" />}
          label="Expenses"
          value={formatCurrency(monthlyExpense, user?.currency || 'HUF')}
          helper="Current expense transactions in the feed."
        />
        <StatCard
          icon={<TrendingUpRoundedIcon color="success" />}
          label="Income"
          value={formatCurrency(monthlyIncome, user?.currency || 'HUF')}
          helper="Current income transactions in the feed."
        />
        <StatCard
          icon={<SavingsRoundedIcon color="secondary" />}
          label="Budgeted"
          value={formatCurrency(budgetLimit, user?.currency || 'HUF')}
          helper="Budget ceilings across tracked categories."
        />
      </Box>

      <Box
        sx={{
          display: 'grid',
          gap: 2.5,
          gridTemplateColumns: { xs: '1fr', lg: 'minmax(0, 1.4fr) minmax(0, 1fr)' },
        }}
      >
        <SectionCard
          title="Recent activity"
          subtitle="Latest transactions from the current user or demo data"
        >
          <List disablePadding>
            {transactions.slice(0, 6).map((transaction) => (
              <ListItem key={transaction.id} disableGutters sx={{ py: 1.25 }}>
                <ListItemAvatar>
                  <Avatar sx={{ bgcolor: transaction.type === 'EXPENSE' ? 'error.light' : 'success.light' }}>
                    {transaction.type === 'EXPENSE' ? '−' : transaction.type === 'INCOME' ? '+' : '⇄'}
                  </Avatar>
                </ListItemAvatar>
                <ListItemText
                  primary={transaction.description || transaction.note || 'Transaction'}
                  secondary={`${transaction.place || 'No place'} • ${formatDate(transaction.date)}`}
                />
                <Stack alignItems="flex-end" spacing={0.5}>
                  <Typography fontWeight={700}>
                    {formatCurrency(transaction.amount, user?.currency || 'HUF')}
                  </Typography>
                  <Chip size="small" label={transaction.type} color="primary" variant="outlined" />
                </Stack>
              </ListItem>
            ))}
          </List>
        </SectionCard>

        <SectionCard
          title="Account snapshot"
          subtitle="A simple card-based summary you can rename later"
          sx={{ height: '100%' }}
        >
          <Stack spacing={1.5}>
            {accounts.map((account) => (
              <Box
                key={account.id}
                sx={{
                  p: 2,
                  borderRadius: 3,
                  border: '1px solid',
                  borderColor: 'divider',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  gap: 2,
                }}
              >
                <Box>
                  <Typography fontWeight={700}>{account.name}</Typography>
                  <Typography variant="body2" color="text.secondary">
                    Icon: {account.icon || 'customize later'}
                  </Typography>
                </Box>
                <Typography fontWeight={800}>
                  {formatCurrency(account.balance, user?.currency || 'HUF')}
                </Typography>
              </Box>
            ))}
          </Stack>
        </SectionCard>
      </Box>
    </Stack>
  );
}
