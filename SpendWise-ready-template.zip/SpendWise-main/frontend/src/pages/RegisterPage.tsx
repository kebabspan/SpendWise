import {
  Alert,
  Box,
  Button,
  Card,
  Link,
  MenuItem,
  Stack,
  TextField,
  Typography,
} from '@mui/material';
import { useState } from 'react';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { siteConfig } from '../lib/site';

export default function RegisterPage() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    currency: 'HUF',
  });
  const [error, setError] = useState('');

  const handleSubmit = async () => {
    try {
      setError('');
      await register(form);
      navigate('/');
    } catch (err) {
      console.error(err);
      setError('Registration failed. The email might already be taken.');
    }
  };

  return (
    <Box sx={{ minHeight: '100vh', display: 'grid', placeItems: 'center', p: 2 }} className="page-gradient">
      <Card sx={{ width: '100%', maxWidth: 480, borderRadius: 5, p: 4, boxShadow: '0 24px 70px rgba(15, 23, 42, 0.12)' }}>
        <Stack spacing={2.5}>
          <Box>
            <Typography variant="overline" color="primary" fontWeight={800}>
              {siteConfig.appName}
            </Typography>
            <Typography variant="h4" fontWeight={900}>
              Create account
            </Typography>
            <Typography color="text.secondary">Use this screen as your ready-made sign-up template.</Typography>
          </Box>
          {error ? <Alert severity="error">{error}</Alert> : null}
          <TextField label="Full name" value={form.name} onChange={(event) => setForm((prev) => ({ ...prev, name: event.target.value }))} fullWidth />
          <TextField label="Email" type="email" value={form.email} onChange={(event) => setForm((prev) => ({ ...prev, email: event.target.value }))} fullWidth />
          <TextField label="Password" type="password" value={form.password} onChange={(event) => setForm((prev) => ({ ...prev, password: event.target.value }))} fullWidth />
          <TextField select label="Currency" value={form.currency} onChange={(event) => setForm((prev) => ({ ...prev, currency: event.target.value }))} fullWidth>
            <MenuItem value="HUF">HUF</MenuItem>
            <MenuItem value="EUR">EUR</MenuItem>
            <MenuItem value="USD">USD</MenuItem>
          </TextField>
          <Button variant="contained" size="large" onClick={() => void handleSubmit()} sx={{ borderRadius: 999 }}>
            Sign up
          </Button>
          <Typography variant="body2" color="text.secondary">
            Already have an account?{' '}
            <Link component={RouterLink} to="/login" sx={{ fontWeight: 700 }}>
              Go to login.
            </Link>
          </Typography>
        </Stack>
      </Card>
    </Box>
  );
}
