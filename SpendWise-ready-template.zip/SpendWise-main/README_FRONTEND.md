# SpendWise frontend template

A csomag tartalmazza a meglévő `backend/` mappát és egy új, rendezett `frontend/` projektet.

## Indítás

### Backend
A docker-compose alapján a backend a `3001` porton fut.

### Frontend
```bash
cd frontend
npm install
npm run dev
```

## Hol tudsz gyorsan átírni mindent?
- `frontend/src/lib/site.ts` → app név, szlogenek, demo szövegek
- `frontend/src/pages/*` → oldalcímek és oldalleírások
- `frontend/src/components/layout/AppShell.tsx` → menü és oldalsáv

## API URL
Alapból:
```env
VITE_API_URL=http://localhost:3001/api
```

Ha máshol fut a backend, másold a `.env.example` fájlt `.env` néven, és írd át.

## Mit tud ez a frontend?
- azonnal megnyíló dashboard template
- kattintható oldalsó menü
- login és register oldalak
- accounts / categories / budgets / transactions / profile oldalak
- demo mód token nélkül
- valódi backend hívások bejelentkezés után
